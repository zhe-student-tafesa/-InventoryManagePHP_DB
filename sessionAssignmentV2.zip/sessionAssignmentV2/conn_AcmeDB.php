<?php
 //连接  产品表
$server="localhost";
$user="root";
$passwordDB=""; //连接  表  密码的名字（passwordDB）不要 与post 传递的变量  重名
$database="Acme";//database name

//echo "<h1>session6</h1>";   //加h1 标签
$link =@ mysqli_connect($server,$user,$passwordDB,$database)//加上@就 没有警告了  //连接  表  密码的名字不要 与post 传递的变量  重名
 or die("unable to connect the database");

//echo "connected to cartDB"; 


?>