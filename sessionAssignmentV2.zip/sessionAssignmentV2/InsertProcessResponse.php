<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Add Product</title>
    </head>
    <body>
        <?php 
            echo "<h1>Add Product </h1>";
            echo "<p>Thank you. Your Form has been processed</p>";
            echo "<p>Product ID is :".$_COOKIE['nameID'].  "</p>";//cookies have been   retrieved. //  get  cookie  //  get  cookie
            $tmp=$_COOKIE['namePic'];
            //echo $tmp;

            echo "<p><img src='$tmp' height='100' width='100'></p>";//namePic
            echo "<a href='ProductForm.php'> Return Product Form </a>";

        ?>
    </body>

</html>