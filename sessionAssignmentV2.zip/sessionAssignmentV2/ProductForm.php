<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Product Entry Form</title>
    <link rel="stylesheet" type="text/css" href="css/mystyles.css">
</head>

<body>

    <?php
    $prodName = "";
    $prodNameErr = "";

    $prodFinish = "";
    $prodFinishErr = "";

    $prodUsage = "";
    $prodUsageErr = "";

    $prodCost = "";
    $prodCostErr = "";
    //文件初始化
    $fileupload="";
    $fileErr = "";
    //////////////
    // $fullName = "";
    // $email = "";
    // $fullNameErr = "";
    // $emailErr = "";

    // $gender = "";
    // $genderErr = "";

    // $pastimeErr = "";//AA定义变量
    // $pastime = "";
    ////////////////

    $invalidData = false;
    if ($_SERVER["REQUEST_METHOD"] == "POST") { //使用post方法 传输数据 222222
        $prodName = checkInput($_POST["prodName"]); //取出值 fullName，然后 调用checkInput 函数进行数据 预处理
        $prodFinish = checkInput($_POST["prodFinish"]);
        $prodUsage = checkInput($_POST["prodUsage"]);
        $prodCost = checkInput($_POST["prodCost"]);




        //********************************************part5 开始
        //storefile.php uses the fields posted from the getfile.html  getfile.html通过【post】把文件信息传递过来
        //and stores it in the product_images table 把“文件路径加名” 存储 在 数据库  product_images 表格  里
        $fileupload = $_FILES['userfile']['name'];
        $filetype = $_FILES['userfile']['type'];

        $filesize = $_FILES['userfile']['size'];
        $tempname = $_FILES['userfile']['tmp_name'];
        $filelocation = "images/$fileupload"; //通过HTML上传的文件：保存在服务器 这个 路径 位置      
        //************************************** **part5  end




        //检查 名字是否为空
        if ($prodName == "") {
            $prodNameErr = "Product Name must not be blank";
            $invalidData = true;
        } else {
            $prodNameErr = ""; //如果数据正确，prodNameErr需要复位 reset
        }


        if ($prodFinish == "") {
            $prodFinishErr = "Product Finish must not be blank";
            $invalidData = true;
        } else {
            $prodFinishErr = ""; //如果数据正确，prodNameErr需要复位 reset
        }



        if ($prodUsage == "") {
            $prodUsageErr = "Product Usage must not be blank";
            $invalidData = true;
        } else {
            $prodUsageErr = ""; //如果数据正确，prodNameErr需要复位 reset
        }

        if ($prodCost == "") {
            $prodCostErr = "Product Cost must not be blank";
            $invalidData = true;
        } else {
            $prodCostErr = ""; //如果数据正确，prodNameErr需要复位 reset
        }

        //   //检查 名字是否为空
        //   if ($fullName == "") {
        //     $fullNameErr = "Family Name must not be blank";
        //     $invalidData = true;
        // } else {
        //     $fullNameErr = ""; //如果数据正确，fullNameErr需要复位
        // }

        //经验 性别


        //校验 娱乐
        //校验文件 开始              //校验文件 开始              //校验文件 开始              //校验文件 开始               
        //make sure a file has been entered
        if ($fileupload == "") {
            //echo "<p>You must enter a filename</p>";
            $invalidData = true;// 文件 错误001
            $fileErr="You must enter a filename";

        } else {
            if( ($filetype=="image/jpeg") || ($filetype=="image/jpg") || ($filetype=="image/bmp") || ($filetype=="image/png")|| ($filetype=="image/tif")|| ($filetype=="image/gif")|| ($filetype=="image/webp")){
                if (!move_uploaded_file($tempname, $filelocation)) { //move_uploaded_file 函数：检查以确保文件 ($tempname) 是有效的上传文件（意味着它已上传
                    //通过 PHP 的 HTTP POST 上传机制）。
                    switch ($_FILES['userfile']['error']) {
                        case UPLOAD_ERR_INI_SIZE: //文件 初始化 大小，默认是2M
                            //echo "<p>Error: File exceeds the maximum size limit set by the server</p>";
                            $invalidData = true;// 文件 错误002
                            $fileErr="Error: File exceeds the maximum size limit set by the server";
                            break;
                        case UPLOAD_ERR_FORM_SIZE: //我们在html 设置的文件  大小，最大1M
                            ///echo "<p>Error: File exceeds the maximum size limit set by the browser</p>";
                            $invalidData = true;// 文件 错误003
                            $fileErr="Error: File exceeds the maximum size limit set by the browser";
                            break;
                        case UPLOAD_ERR_NO_FILE:    //没有文件 
                            //echo "<p>Error: No file uploaded</p>";
                            $invalidData = true;// 文件 错误004
                            $fileErr="Error: No file uploaded";
                            break;
                        default:
                            //echo "<p>File could not be uploaded </p>";
                            $invalidData = true;// 文件 错误005
                            $fileErr="File could not be uploaded";
                    }
                } else {
                    //正常情况  如果数据正确，fileErr需要复位 reset，//正常情况  如果数据正确，fileErr需要复位 reset
                    $fileErr="";
    
                    
                } 
            }else{//文件 类型错误
                $invalidData = true;// 文件 错误002
                $fileErr="Error: Please select a file of image type";

            }

        }


        //校验文件 结束 //校验文件 结束//校验文件 结束//校验文件 结束




        if ($invalidData == false) { /*  call process.php */
            //header('Location: customerStats.html');
            include("InsertProcess.php");
            header('location: InsertProcessResponse.php'); //header 需要加 ；location
            exit();
        }
    }
    function checkInput($inputData)
    {
        $inputData = trim($inputData); //去除 两端的空格
        $inputData = stripslashes($inputData); //去掉反斜杠的字符串。 （\'   变成 '   等等。）双反斜杠 (\\) 变成一个反斜杠 (\)
        $inputData = htmlspecialchars($inputData); //Convert special characters to HTML entities 将特殊字符转换为 HTML 实体
        return $inputData;
    }
    ?>


    <a href="ProductForm.php">Add Product</a>
    <a href="UpdateForm.php">Update Product</a>
    <a href="DeleteForm.php">Delete Product</a>

    <h1>Product Entry Form</h1>
    <h2>Enter the Door Lever Product details into the  Form and when you are ready, click the submit button.</h2>
    <p>NOTE: denotes required entry</p>

    <!-- <form id="custForm" name="custForm" method="post" action=<?php echo $_SERVER["PHP_SELF"]; ?>> -->
    <!-- 使用post方法111111 -->
    <form id="custForm" name="custForm" method="post" enctype='multipart/form-data' action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>>



        <label for="prodName">Product Name :</label><input name="prodName" id="prodName" type="text" value="<?php echo $prodName; ?>" />
        <span class="error">* <?php echo $prodNameErr; ?></span><br /><br />

        <label for="prodFinish">Product Finish :</label><input name="prodFinish" id="prodFinish" type="text" value="<?php echo $prodFinish; ?>" />
        <span class="error">* <?php echo $prodFinishErr; ?></span><br /><br />

        <label for="prodUsage">Product Usage:</label><input name="prodUsage" id="prodUsage" type="text" value="<?php echo $prodUsage; ?>" />
        <span class="error">* <?php echo $prodUsageErr; ?></span><br /><br />

        <label for="prodCost">Product Cost:</label><input name="prodCost" id="prodCost" type="text" value="<?php echo $prodCost; ?>" />
        <span class="error">* <?php echo $prodCostErr; ?></span><br /><br />

        <input type='hidden' name='MAX_FILE_SIZE' value='1048576'>

        <label for="userfile">Send this file</label><input type='file' id='userfile' name='userfile' value="<?php echo $fileupload; ?>" />
        <span class="error">* <?php echo $fileErr; ?></span>
        <br /><br />






        <br /><br />
        <br />



        <br /><br />

        <br />
        <br />
        <input name="submit" type="submit" value="Submit" />
        <input type="submit" name="reset" value="Reset" title="Reset Form" />
    </form>


</body>

</html>