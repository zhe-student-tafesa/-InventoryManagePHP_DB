<?php
$link = mysqli_connect("localhost", "root", "");
// Check connection
if (mysqli_connect_errno()) {
    echo "<p>Failed to connect to MySQL: " . mysqli_connect_error() . "</p>";
} else {
    echo "<p>Connected to mysql</p>";
    // Create database and table
    //$query = "DROP DATABASE IF EXISTS acme;";
    $query= "CREATE DATABASE IF NOT EXISTS acme;";
    $query.= "USE acme;";



//create acmeproducts TABLE
    $query.= "CREATE TABLE IF NOT EXISTS acmeproducts (
              id int not null primary key AUTO_INCREMENT,
                prodName   Varchar(30) not null, 
                prodFinish Varchar(30) not null, 
                prodUsage  Varchar(30) not null, 
                prodCost   decimal(8,2),
                ProductsImage varchar(100)
        ) ;";
    $query.= "INSERT INTO acmeproducts (prodName, prodFinish, prodUsage,prodCost,ProductsImage) 
                VALUES ('Joe', 'B', 'use',888,'a.jpg');";
    
    

     
    
    //create acmeusers TABLE
    $query.= "CREATE TABLE IF NOT EXISTS acmeusers (
        username varchar(255) primary key,
       
        userPassword varchar(255)
     ) ;";



     //name=joe_bloggs     password=123456
     $password=123456;
     $myHashedPassword = password_hash($password,PASSWORD_DEFAULT);
    $query.= "INSERT INTO acmeusers (username, userPassword) 
          VALUES ('joe_bloggs', '$myHashedPassword')";


//var_dump($query);


    if (mysqli_multi_query($link, $query)) {
        //echo "<p>Database acme, acmeproducts TABLE and acmeusers TABLE created successfully</p>";
        do {
            mysqli_next_result($link);
        } while (mysqli_more_results($link));
    } else {
        //echo "<p>Error: " . mysqli_error($link) . "</p>";
    }
}
