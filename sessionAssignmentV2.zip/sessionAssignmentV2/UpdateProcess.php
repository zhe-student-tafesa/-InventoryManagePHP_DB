<?php
session_start(); ///////////////////////////开始session
//$_SESSION['user_name']
if($_SESSION['user_name']!="Root Admin"){//if not  root
    echo "please login root user";
    echo"<p> <a href=index.php>Click Here to Login</a> </b></p>";
    exit();
   
}else{//if not  root
    require_once('conn_AcmeDB.php');
        //加密 成 32位，然后保存
       // $password=md5($password);  暂时 不加密

    //echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    //var_dump($_POST['prodName']);
    $query = "update  AcmeProducts  set prodCost='".$prodCost."' where id =".$id;
    $result= mysqli_query($link, $query);
    $numRowsAffected=mysqli_affected_rows($link);
    if(!$result){// 1                         .    2              .  3
        echo "<p>Error updating product cost:".mysqli_error($link)."</p>";

    }else{
        if($numRowsAffected == 0){
            echo "<p>Error -product ID not found-</p>";
        }else{
            echo "<p>product cost successfully updated for product ID: ".$id."</p>";
            //select...
            $query = "select * from AcmeProducts  where id=".$id;
            $results= mysqli_query($link, $query);
            if($results){
                $numRecords=mysqli_num_rows($results);
                if($numRecords !=0){
                    //fetch and display results
                    while($row=mysqli_fetch_array($results)){
                        echo "<p>id: $row[id]</p>";
                        echo "<p>product Name: $row[prodName]</p>";
                        echo "<p>product Finish: $row[prodFinish]</p>";
                        echo "<p>product Usage: $row[prodUsage]</p>";
                        echo "<p>product Cost: $row[prodCost]</p>";
                    }

                }else{
                    echo "<p>product id not found ! </p>";
                }
            }


        }
    }


    // $query = "INSERT INTO AcmeProducts ( prodName, prodFinish, prodUsage, prodCost)VALUES 
    //     ('$_POST[prodName]','$_POST[prodFinish]','$_POST[prodUsage]','$_POST[prodCost]')";//注意 顺序，   have order
        
	//Run the query
    //mysqli_query($link, $query) or die( "Unable to insert the record");

 

    mysqli_close($link);

}


    ?>