<?php
require_once('conn_AcmeDB.php');
        //加密 成 32位，然后保存
       // $password=md5($password);  暂时 不加密

    //echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    //var_dump($_POST['prodName']);
    $myHashedPassword = password_hash($password,PASSWORD_DEFAULT);
    
    $query = "INSERT INTO acmeusers ( username, userPassword)VALUES 
        ('$name','$myHashedPassword')";//注意 顺序，   have order
        
	//Run the query
    //mysqli_query($link, $query) or die( "Unable to insert the record");

    if ( mysqli_query($link, $query)){
        //$thisProdId = mysqli_insert_id($link);//get id
        setcookie("CUsername",$name, time() + (86400 * 1));//cookie
        
        //echo $thisProdId;

    }else{
        die( "Unable to insert the record");

    }


    mysqli_close($link);

    ?>