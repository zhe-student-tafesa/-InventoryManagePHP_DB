<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <link rel="stylesheet" type="text/css" href="css/mystyles.css">
</head>

<body>

    <?php
    //require_once('DoWhileCreateDB.php');
    $name= "";
    $nameErr= "";

    $password= "";
    $passwordErr= "";

//////////////
    // $fullName = "";
    // $email = "";
    // $fullNameErr = "";
    // $emailErr = "";

    // $gender = "";
    // $genderErr = "";

    // $pastimeErr = "";//AA定义变量
    // $pastime = "";
////////////////

    $invalidData = false;
    if ($_SERVER["REQUEST_METHOD"] == "POST") { //使用post方法 传输数据 222222
        $name= $_POST["name"]; //取出值 fullName，然后 调用checkInput 函数进行数据 预处理
        $password= $_POST["password"];


        //检查 名字是否为空
        if ($name== "") {
            $nameErr= "User Name must not be blank";
            $invalidData = true;
        } else {
            $nameErr= ""; //如果数据正确，prodNameErr需要复位 reset
        }


        if ($password== "") {
            $passwordErr= "Password must not be blank";
            $invalidData= true;
        } else {
            $passwordErr= ""; //如果数据正确，prodNameErr需要复位 reset
        }



        //   //检查 名字是否为空
        //   if ($fullName == "") {
        //     $fullNameErr = "Family Name must not be blank";
        //     $invalidData = true;
        // } else {
        //     $fullNameErr = ""; //如果数据正确，fullNameErr需要复位
        // }
       
        //经验 性别

       
        //校验 娱乐

        


        if ($invalidData == false) { /*  call process.php */
            //header('Location: customerStats.html');
            include("LoginProcess.php");
            //header('location: AddUserProcessResponse.php');//header 需要加 ；location
            exit();
        }
    }
    function checkInput($inputData)
    {
        $inputData = trim($inputData); //去除 两端的空格
        $inputData = stripslashes($inputData); //去掉反斜杠的字符串。 （\'   变成 '   等等。）双反斜杠 (\\) 变成一个反斜杠 (\)
        $inputData = htmlspecialchars($inputData); //Convert special characters to HTML entities 将特殊字符转换为 HTML 实体
        return $inputData;
    }
    ?>



    
    <h1>Login Form</h1>
    <h2>Enter the username and password and when you are ready, click the submit button.</h2>
    <p>NOTE: denotes required entry</p>

    <!-- <form id="custForm" name="custForm" method="post" action=<?php echo $_SERVER["PHP_SELF"]; ?>> -->
    <!-- 使用post方法111111 -->
    <form id="custForm" name="custForm" method="post" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>>

     

        <label for="name">User Name :</label><input name="name" id="name" type="text" value="<?php echo $name; ?>" />
        <span class="error">* <?php echo $nameErr; ?></span><br /><br />

        <label for="password">Password :</label><input name="password" id="password" type="text" value="<?php echo $password; ?>" />
        <span class="error">* <?php echo $passwordErr; ?></span><br /><br />





        
        <br/><br/>
        <br/>


       
        <br/><br/>

        <br />
        <br />
        <input name="submit" type="submit" value="Submit" />
        <input type="submit" name="reset" value="Reset" title="Reset Form" />
    </form>


</body>

</html>