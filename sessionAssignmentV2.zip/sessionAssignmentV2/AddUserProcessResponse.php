<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Add Product</title>
    </head>
    <body>
        <?php 
            echo "<h1>Add User </h1>";
            echo "<p>Thank you. Your Form has been processed</p>";
            echo "<p>User name is :".$_COOKIE['CUsername'].  "</p>";
            echo "<a href='ProductForm.php'> Return Product Form </a>";

        ?>
    </body>

</html>