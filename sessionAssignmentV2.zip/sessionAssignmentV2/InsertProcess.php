<?php
require_once('conn_AcmeDB.php');
        //加密 成 32位，然后保存
       // $password=md5($password);  暂时 不加密

    //echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    //var_dump($_POST['prodName']);
    $thisProdId=0;
    
    $query = "INSERT INTO AcmeProducts ( prodName, prodFinish, prodUsage, prodCost,	ProductsImage)VALUES 
        ('$prodName','$prodFinish','$prodUsage','$prodCost','$filelocation')";//注意 顺序，   have order
        
	//Run the query
    //mysqli_query($link, $query) or die( "Unable to insert the record");

    if ( mysqli_query($link, $query)){
        $thisProdId = mysqli_insert_id($link);//get id
        setcookie("nameID",$thisProdId, time() + (86400 * 1));//cookie   cookies have been set   cookie    cookie    cookie    cookie  
        setcookie("namePic",$filelocation, time() + (86400 * 1));//cookie
        //echo $thisProdId;

    }else{
        die( "Unable to insert the record");

    }


/* 
    ///////////////////////////////////////////////////////////insert img according id  begin
//Open the mycompany database and make sure the product_images table is present   需要获取 id
include('conn_AcmeDB.php'); //连接 数据库
///////////////$dbQuery = "INSERT INTO product_images(id，imageurl) VALUES ('$thisProdId','$filelocation')"; //插入 ：“文件路径加名” 存储 在 数据库  product_images 表格  里

$dbQuery = "INSERT INTO product_images ( id, imageurl)VALUES ('$thisProdId','$filelocation')";
if (mysqli_query($link, $dbQuery)) {
    echo "<!DOCTYPE html>";
    echo "<html lang='en'>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<title>File Upload</title>";


    echo "</head>";
    echo "<body>";
    echo "<h1>File Uploaded</h1>";
    // 打印图片      // 打印图片 
    echo "<p><img src='$filelocation' height='300' width='200'></p>";

    echo "The details of the uploaded file are shown below:<br/>";
    // 打印图片 的 详细信息 
    echo "<b>File Name: </b>$fileupload<br/> ";
    echo "<b>File type: </b>$filetype<br/> ";
    echo "<b>File size: </b>$filesize bytes<br/> ";
    echo "<b>Uploaded to: </b>$tempname<br/> ";
    echo "<a href='getfile.html'>Add Another file</a>";
    echo "</body>";
    echo "</html>";
} else {
    echo "<p>Couldn't add the file to the database " . mysqli_error($link) . "</p>";
}
    ///////////////////////////////////////////////////////////////insert img according id  end
*/

    mysqli_close($link);

    ?>