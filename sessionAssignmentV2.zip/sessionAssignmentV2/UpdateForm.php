<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Product Update Form</title>
    <link rel="stylesheet" type="text/css" href="css/mystyles.css">
</head>

<body>

    <?php
    $id= "";
    $idErr= "";
 

    $prodCost= "";
    $prodCostErr= "";
//////////////
    // $fullName = "";
    // $email = "";
    // $fullNameErr = "";
    // $emailErr = "";

    // $gender = "";
    // $genderErr = "";

    // $pastimeErr = "";//AA定义变量
    // $pastime = "";
////////////////

    $invalidData = false;
    if ($_SERVER["REQUEST_METHOD"] == "POST") { //使用post方法 传输数据 222222
        $id= checkInput($_POST["id"]); //取出值 fullName，然后 调用checkInput 函数进行数据 预处理
       
        $prodCost= checkInput($_POST["prodCost"]);

        //检查 名字是否为空
        if ($id== "") {
            $idErr= "Product Id must not be blank";
            $invalidData = true;
        }else {
            $idErr= ""; //如果数据正确，prodNameErr需要复位 reset
        }

 

        if ($prodCost== "") {
            $prodCostErr= "Product Cost must not be blank";
            $invalidData= true;
        }else if(!is_numeric($prodCost)){
            //$idErr= ""; //not a number
            $prodCostErr= "Product cost must  be a number";
            $invalidData = true;
        }elseif($prodCost<20 or $prodCost>200){
            $prodCostErr= "ProductCost must  be 20~200";
            $invalidData = true;

        }else {
            $prodCostErr= ""; //如果数据正确，prodNameErr需要复位 reset
        }

        //   //检查 名字是否为空
        //   if ($fullName == "") {
        //     $fullNameErr = "Family Name must not be blank";
        //     $invalidData = true;
        // } else {
        //     $fullNameErr = ""; //如果数据正确，fullNameErr需要复位
        // }
       
        //经验 性别

       
        //校验 娱乐

        


        if ($invalidData == false) { /*  call process.php */
            //header('Location: customerStats.html');
            include("UpdateProcess.php");
            include("UpdateProcessResponse.php");
            exit();
        }
    }
    function checkInput($inputData)
    {
        $inputData = trim($inputData); //去除 两端的空格
        $inputData = stripslashes($inputData); //去掉反斜杠的字符串。 （\'   变成 '   等等。）双反斜杠 (\\) 变成一个反斜杠 (\)
        $inputData = htmlspecialchars($inputData); //Convert special characters to HTML entities 将特殊字符转换为 HTML 实体
        return $inputData;
    }
    ?>



    <h1>Product Update Form</h1>

    <a href="ProductForm.php">Add Product</a> 
    <a href="UpdateForm.php">Update Product</a>
    <a href="DeleteForm.php">Delete Product</a>
    
    <h2>Enter the Door Lever Product id and new cost into the  Form and when you are ready, click the submit button.</h2>
    <p>NOTE:* denotes required entry</p>

    <!-- <form id="custForm" name="custForm" method="post" action=<?php echo $_SERVER["PHP_SELF"]; ?>> -->
    <!-- 使用post方法111111 -->
    <form id="custForm" name="custForm" method="post" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>>

     

        <label for="id">Product ID :</label><input name="id" id="id" type="text" value="<?php echo $id; ?>" />
        <span class="error">* <?php echo $idErr; ?></span><br /><br />


        <label for="prodCost">Product Cost:</label><input name="prodCost" id="prodCost" type="text" value="<?php echo $prodCost; ?>" />
        <span class="error">* <?php echo $prodCostErr; ?></span><br /><br />



        
        <br/><br/>
        <br/>


       
        <br/><br/>

        <br />
        <br />
        <input name="submit" type="submit" value="Submit" />
        <input type="submit" name="reset" value="Reset" title="Reset Form" />
    </form>


</body>

</html>