<?php
$conn = mysqli_connect("localhost", "root", "");
// Check connection
if (mysqli_connect_errno()) {
    echo "<p>Failed to connect to MySQL: " . mysqli_connect_error() . "</p>";
} else {
    echo "<p>Connected to MySQL</p>";
}

// Create database
$createDB = "DROP DATABASE IF EXISTS acme;";
$createDB .= "CREATE DATABASE acme;"; //拼串，写出2条sql语句 "DROP DATABASE IF EXISTS acme; CREATE DATABASE acme;

if (mysqli_multi_query($conn, $createDB)) {
    echo "<p>Database acme created successfully</p>";
    do {//The do … while loop is needed to move on to the next command in the multi query  set
  
        mysqli_next_result($conn);
    } while (mysqli_more_results($conn));
} else {
    echo "<p>Error: " . mysqli_error($conn) . "</p>";
}
