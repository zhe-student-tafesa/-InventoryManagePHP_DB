<?php
session_start(); ///////////////////////////开始session
require_once('conn_AcmeDB.php');
        //加密 成 32位，然后保存
       // $password=md5($password);  暂时 不加密

    //echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    //var_dump($_POST['prodName']);
    //$myHashedPassword = password_hash($password,PASSWORD_DEFAULT);
    
    
    //////////////////////////////////////////////EWD begin
    $query = " SELECT * 
				from acmeusers WHERE (username = '$name') "; //customer no  s   '$email'加单引号


	$result = mysqli_query($link, $query) or die("Invalid Customer ID or Password"); ////如果查询不成功，则die

	//get the number of rows in the result set; should be 1 if a match
	if (mysqli_num_rows($result) == 1) {///////////////////////////////////////成功登录1、保存数据到session
		//if authorized, get the values of firstname lastname, phone and email
		$row = $result->fetch_row(); //********* 查询结果赋值给  $row
		$name = $row[0];
		$myHashedPassword = $row[1];
		 
		mysqli_close($link);//关闭 数据库连接
		//save the values in session variables把变量保存在 session里面
		// $_SESSION['first_name'] = $first_name;
		// $_SESSION['last_name'] = $last_name;
		// $_SESSION['phone'] = $phone;
		// $_SESSION['email'] = $email;

        $passwordsAreSame=password_verify($password,$myHashedPassword);
        if($passwordsAreSame==true){
            $_SESSION['user_name'] = $name;


            echo "<h2> Authentication Succeed !!! </h2>";
            echo "password match";
            echo"<p> <a href=ProductForm.php>Click Here to Product Entry Form</a> </b></p>";

        }
        else{
            echo "password  do not match";
            echo"<p> <a href=index.php>Click Here to Login</a> </b></p>";
            exit();
        }
		
		//echo "<a href=member_page.php> Click Here to goto Member Page </a>";
	} else {
		//Redirect user back to the login page
		echo"<p> <a href=index.php>Click Here to Login</a> </b></p>";
        mysqli_close($link);
		exit();
	}

    //////////////////////////////////////////////EWD end

    

    ?>